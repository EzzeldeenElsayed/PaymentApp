
#include <stdio.h>
#include "Application/app.h"

#pragma warning( disable : 4996 )



int main() {
	appStart();
	printf("\n\t--===EXITING PROGRAM===--\n");
}